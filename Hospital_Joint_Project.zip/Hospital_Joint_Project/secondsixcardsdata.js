let six_cards_icon=[
    '<i class="fa-solid fa-pills"></i>',
    '<i class="fa-solid fa-vial-virus"></i>',
    '<i class="fa-solid fa-house-medical-flag"></i>',
    '<i class="fa-solid fa-vial-virus"></i>',
    '<i class="fa-solid fa-vial-virus"></i>',
    '<i class="fa-solid fa-house-medical-flag"></i>'
]
let six_cards_titles=['Our Medicine Dept', 'Center Treatment', 'Modern Equiments','Center Treament','Center treatment','Modern Equipment']
let six_cards_link_text='Find services'
export default{
    six_cards_icon,
    six_cards_titles,
    six_cards_link_text,
}
