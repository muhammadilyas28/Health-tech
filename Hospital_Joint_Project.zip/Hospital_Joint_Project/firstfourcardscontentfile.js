let four_body_cards_icons_array=['./1.png','./2.png','./3.png','./4.png']

let title_four_cards_array=['Emergency Contact','Appointment','Doctors TImetable','Working Time']
let button_details=['View Now', 'Make Now', 'View Now', 'Learn More']

let four_cards_details_array='Lorem ipsum nolar st consecrator odipiscing cliturs. Pollontosquo amoturna eget dolor tem.por'

export default{

    four_body_cards_icons_array,
    title_four_cards_array,
    four_cards_details_array,
    button_details
}
